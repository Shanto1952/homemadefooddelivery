    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <h2 class="footer-title">Your Favorite Food, Delivered!</h2>
            
            <nav class="footerNav">
                <ul>
                    <li><a href="#">About us</a></li>
                    <li><a href="#">Delivery</a></li>
                    <li><a href="#">Help & Support</a></li>
                    <li><a href="#">T&C</a></li>
                </ul>
            </nav>
            
            <div class="contact-info">
                <p>Contact: <span> +880 1984745679 </span></p>
            </div>
            
            <div class="social-icons">
                <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                <a href="#" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
            </div>
        </div>
    </footer>
    
</body>
</html>